#include <stdio.h>
#include <stdlib.h>

struct node {
	int dado;
	struct node* proximoNode;
};

struct node* removeDaPilha(struct node*);
struct node* insereNodeNoComecoDaLista(struct node*, int);

void imprimeLista(struct node*);


int main(void){

	/*
				                                                                   │
				                        Remove do começo                           │
				                                   x                               │
				                         xxxx     xx                               │
		     Insere no começo                  xx    xxxxxx xxx                            │
		      xxx xx xxxxx                    xx         x   xx                            │
				  xx                xx          xxx                                │
				   x x            xxx                                              │
				xx  xx            x                                                │
		 TOPO  1o. NO       x           xx                                                 │                                                  9                  6
				  xx            x                                                  │                          │     x                 x                  X                 5
			x       ┌──────────────────────┐                                           │                          │                       x                  x                 X
		xxxxxxxxxxx     │                      │                                           │                          │
			xxx     │                      │                         x                 │                          │              ┌────────────┐    ┌────────────┐     ┌────────────┐
				│                      │                         xx                │                          │              │            │    │            │     │            │
				├──────────────────────┤                          x                │                          └────────────► │            │    │            │     │            │
				│                      │                           x               │                                         │            │    │            │     │            │
			x       │                      │     ...                   x               │                                         │            │    │            │     │            │
		      xxx       │                      │                           x               │                                       ┌─┤         ───┼───►│            ├────►│            │
		     x  xx      ├──────────────────────┤                            x              │                                       │ │            │    │            │     │            │
		    x    xx     │                      │                            x              │                                       │ └────────────┘    └────────────┘     └────────────┘
		  xxxx xxxxx    │                      │   Quarto                   x              │                                       │
		       x        │                      │                            x              │                                       │
		       x        ├──────────────────────┤                           x               │                                       │
		       x        │                      │                                           │                                       │
		       x        │                      │  Terceiro                 x               │                                       │
		       x        │                      │                                           │                                       │
		       x        ├──────────────────────┤                           x               │                                       └─────────────►
		       x        │                      │                           x               │
		       x        │                      │   Segundo                x                │
				│                      │                          x                │
			x       ├──────────────────────┤                     xx xxxxxxx            │
				│                      │                    xx                     │
			x       │                      │   Primeiro          xx                    │
			x       │                      │                       x                   │
			xx      └──────────────────────┘                       xxx                 │
				                                                                   │
				                                                                   │
				                                                                   │
				                                                                   │
				                                                                   │
				                                                                   │
				                                                                   │
	*/

	printf("Começou nova implementação\n");

	struct node* primeiroNodeInicio = NULL;

	for (int i = 0; i < 3; i++) {

		int x;

		printf("Insira um inteiro: \n");
		scanf("%d", &x);

		primeiroNodeInicio = insereNodeNoComecoDaLista(primeiroNodeInicio, x);
	}

	printf("Apos primeiras inserções:\n");
	imprimeLista(primeiroNodeInicio);

	primeiroNodeInicio = removeDaPilha(primeiroNodeInicio);
	primeiroNodeInicio = removeDaPilha(primeiroNodeInicio);

	printf("\n\nDepois das remoções:\n");
	imprimeLista(primeiroNodeInicio);

	int x;
	printf("\nInsira um inteiro: \n");
	scanf("%d", &x);
	primeiroNodeInicio = insereNodeNoComecoDaLista(primeiroNodeInicio, x);

	printf("\n\nDepois da última inserção:\n");
	imprimeLista(primeiroNodeInicio);


	printf("\nAcabou nova implementação\n");


	return 0;
}

struct node* removeDaPilha(struct node* primeiroNode) { //Pop

	struct node* atualNode = primeiroNode;
	struct node* paraDeletarNode = NULL;

	if(atualNode != NULL){
		paraDeletarNode = atualNode;
		atualNode = atualNode->proximoNode;

		free(paraDeletarNode);
	}

	return atualNode;
}


//Igual para pilha
struct node* insereNodeNoComecoDaLista(struct node* pNode, int numero) { //Push

	struct node* novoNode = NULL;

	novoNode = (struct node*)malloc(sizeof(struct node));
	novoNode->dado = numero;
	novoNode->proximoNode = pNode;

	return novoNode;
}


void imprimeLista(struct node* pNode) {

	struct node* atualNodeImpressao = pNode;

	while(atualNodeImpressao != NULL) {
		printf("O valor do dado é %d e end. do próximo é 0x%x.\n", atualNodeImpressao->dado, atualNodeImpressao->proximoNode);
		//if(atualNodeImpressao->proximoNode != NULL)
		//	printf("EXEMPLO: O valor do dado é %d e valor do próximo dado é %d.\n", atualNodeImpressao->dado, atualNodeImpressao->proximoNode->dado);
		atualNodeImpressao = atualNodeImpressao->proximoNode;
	}
}


