#include <stdio.h>
#include <stdlib.h>

struct node {
	int dado;
	struct node* proximoNode;
};

struct node* removeDaFila(struct node*);
struct node* insereNodeNoFinalDaLista(struct node*, int);
void imprimeLista(struct node*);


int main(void){


	/*
			Fila

                          Fim                                                              Começo


                              ┌───────────┐     ┌───────────┐    ┌───────────┐     ┌───────────┐
                              │           │     │           │    │           │     │           │
                              │           │     │           │    │           │     │           │          Servidores
     Entrada                  │           │     │           │    │           │     │           │
                              │           │     │           │    │           │     │           │
                NULL     ◄────┼────       │ ◄───┼────       │ ◄──┼──         │◄────┼───        │
                              │           │     │           │    │           │     │           │
                              └───────────┘     └───────────┘    └───────────┘     └───────────┘

                                   4                 3                 2                1
                                                     4                 3                2
                                                                       4                3
                                                                                        4
                                                                                        X

                                   4                 3                 2                1
                                                     4                 3                2
                                                                       4                3
                                                     5                 4                3
                                   6                 5                 4                3
                     7             6                 5                 4                3



	 * */





	printf("Começou nova implementação\n");

	struct node* primeiroNodeFinal = NULL; //lista em branco, inexistente

	for (int i = 0; i < 3; i++) {

		int x;

		printf("Insira um inteiro: \n");
		scanf("%d", &x);

		primeiroNodeFinal = insereNodeNoFinalDaLista(primeiroNodeFinal, x);
	}


	printf("\n\nPrimeira impressão de nodes:\n");
	imprimeLista(primeiroNodeFinal);

	primeiroNodeFinal = removeDaFila(primeiroNodeFinal);
	primeiroNodeFinal = removeDaFila(primeiroNodeFinal);

	printf("\n\nSegunda impressão de nodes:\n");
	imprimeLista(primeiroNodeFinal);

	int x;
	printf("Insira um inteiro: \n");
	scanf("%d", &x);
	primeiroNodeFinal = insereNodeNoFinalDaLista(primeiroNodeFinal, x);

	printf("\n\nTerceira impressão de nodes:\n");
	imprimeLista(primeiroNodeFinal);


	printf("\nAcabou nova implementação\n");


	return 0;
}

struct node* removeDaFila(struct node* primeiroNode) {

	struct node* atualNode = primeiroNode;

	if(primeiroNode != NULL) {
		atualNode = primeiroNode->proximoNode;

		free(primeiroNode);
	}

	return atualNode;
}


struct node* insereNodeNoFinalDaLista(struct node* pNode, int numero) {

	struct node* primeiroNode = pNode;
	struct node* atualNode = pNode;
	struct node* novoNode = NULL;

	novoNode = (struct node*)malloc(sizeof(struct node));
	novoNode->dado = numero;
	novoNode->proximoNode = NULL;


	if(atualNode != NULL) { //Lista não vazia

		while(atualNode->proximoNode != NULL) {
			atualNode = atualNode->proximoNode;
		}

		atualNode->proximoNode = novoNode;

	} else { //Lista vazia
		primeiroNode = novoNode;
	}

	return primeiroNode;
}


void imprimeLista(struct node* pNode) {

	struct node* atualNodeImpressao = pNode;

	while(atualNodeImpressao != NULL) {
		printf("O valor do dado é %d e end. do próximo é 0x%x.\n", atualNodeImpressao->dado, atualNodeImpressao->proximoNode);
		//if(atualNodeImpressao->proximoNode != NULL)
		//	printf("EXEMPLO: O valor do dado é %d e valor do próximo dado é %d.\n", atualNodeImpressao->dado, atualNodeImpressao->proximoNode->dado);
		atualNodeImpressao = atualNodeImpressao->proximoNode;
	}
}


